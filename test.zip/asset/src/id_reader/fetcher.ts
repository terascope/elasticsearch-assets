
import Processor from '../elasticsearch_reader/fetcher';

export default Processor;
